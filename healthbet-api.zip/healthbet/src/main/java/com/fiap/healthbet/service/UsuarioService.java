package com.fiap.healthbet.service;

import com.fiap.healthbet.domain.Usuario;
import com.fiap.healthbet.domain.dto.AcessosResponse;
import com.fiap.healthbet.domain.dto.UsuarioRequest;
import com.fiap.healthbet.repository.AcessoRepository;
import com.fiap.healthbet.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository repository;

    @Autowired
    private AcessoRepository acessoRepository;

    public Usuario save(UsuarioRequest dto){
        Usuario usuario = new Usuario(dto);
        return repository.save(usuario);
    }

    public List<Usuario> findAll(){
        return repository.findAll();
    }

    public Optional<Usuario> findById(Long id){
        return repository.findById(id);
    }


    @Transactional(readOnly = true)
    public List<AcessosResponse> listarAcessosPorUsuario(Long idUsuario) {
        if (!repository.existsById(idUsuario)) {
            throw new jakarta.persistence.EntityNotFoundException(
                    "Usuário não encontrado com ID: " + idUsuario);
        }
        return acessoRepository.listarPorUsuario(idUsuario);
    }

}
