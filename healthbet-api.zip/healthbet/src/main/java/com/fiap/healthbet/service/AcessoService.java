package com.fiap.healthbet.service;

import com.fiap.healthbet.domain.Acesso;
import com.fiap.healthbet.domain.Usuario;
import com.fiap.healthbet.domain.dto.AcessoRequest;
import com.fiap.healthbet.repository.AcessoRepository;
import com.fiap.healthbet.repository.UsuarioRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AcessoService {
    @Autowired
    AcessoRepository acessoRepository;
    @Autowired
    UsuarioService usuarioService;




    public Acesso novoAcesso(AcessoRequest dto) {
        Usuario u = usuarioService.findById(dto.getIdUsuario())
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado com ID: " + dto.getIdUsuario()));
        Acesso acesso = new Acesso();
        acesso.setNomeUsuario(u.getNome());
        acesso.setUsuario(u);
        acesso.setDataAcesso(LocalDateTime.now());

        return acessoRepository.save(acesso);
    }

}
