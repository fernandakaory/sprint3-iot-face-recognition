package com.fiap.healthbet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthbetApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthbetApplication.class, args);
	}

}
