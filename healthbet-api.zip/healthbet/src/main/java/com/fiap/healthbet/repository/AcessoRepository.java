package com.fiap.healthbet.repository;

import com.fiap.healthbet.domain.Acesso;
import com.fiap.healthbet.domain.dto.AcessosResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AcessoRepository extends JpaRepository<Acesso,Long> {


    @Query("""
           select new com.fiap.healthbet.domain.dto.AcessosResponse(a.id, a.dataAcesso)
           from Acesso a
           where a.usuario.id = :usuarioId
           order by a.dataAcesso desc
           """)
    List<AcessosResponse> listarPorUsuario(@Param("usuarioId") Long usuarioId);

}
