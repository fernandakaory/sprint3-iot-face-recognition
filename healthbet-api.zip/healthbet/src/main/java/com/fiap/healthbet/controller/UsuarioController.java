package com.fiap.healthbet.controller;

import com.fiap.healthbet.domain.dto.AcessosResponse;
import com.fiap.healthbet.domain.dto.UsuarioRequest;
import com.fiap.healthbet.repository.UsuarioRepository;
import com.fiap.healthbet.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    @PostMapping
    public ResponseEntity<UsuarioRequest> save(@RequestBody UsuarioRequest dto){
        return ResponseEntity.status(201).body(new  UsuarioRequest().toDto(service.save(dto)));
    }


    @GetMapping("/{id}/acessos")
    public ResponseEntity<List<AcessosResponse>> listarAcessos(@PathVariable Long id) {
        return ResponseEntity.ok(service.listarAcessosPorUsuario(id));
    }

}
