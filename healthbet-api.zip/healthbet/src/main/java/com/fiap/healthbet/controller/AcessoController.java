package com.fiap.healthbet.controller;

import com.fiap.healthbet.domain.Acesso;
import com.fiap.healthbet.domain.dto.AcessoRequest;
import com.fiap.healthbet.service.AcessoService;
import com.fiap.healthbet.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("acessos")
public class AcessoController {

    @Autowired
    public AcessoService service;


    @PostMapping
    public ResponseEntity<Acesso> criarAcesso(@RequestBody @Valid AcessoRequest dto) {
        var acesso = service.novoAcesso(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(acesso);
    }

}
