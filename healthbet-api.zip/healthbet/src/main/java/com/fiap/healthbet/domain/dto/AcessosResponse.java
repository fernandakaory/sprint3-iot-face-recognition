package com.fiap.healthbet.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDateTime;


@AllArgsConstructor
@Getter
public class AcessosResponse {
    private Long idAcesso;
    private LocalDateTime dataAcesso;
}
