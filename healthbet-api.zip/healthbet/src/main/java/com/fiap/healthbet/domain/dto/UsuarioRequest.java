package com.fiap.healthbet.domain.dto;

import com.fiap.healthbet.domain.Usuario;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UsuarioRequest {
    private String nickname;
    private String nome;

    public UsuarioRequest toDto(Usuario usuario) {
        this.nickname = usuario.getNickname();
        this.nome = usuario.getNome();
        return this;
    }
}
