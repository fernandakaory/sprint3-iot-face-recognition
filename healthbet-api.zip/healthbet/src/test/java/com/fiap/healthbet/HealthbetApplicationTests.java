package com.fiap.healthbet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthbetApplicationTests {

	@Test
	void contextLoads() {
	}

}
